import os

srcpath = os.path.dirname(os.path.abspath(__file__))
name = "hap"
version = "0.1.0"
modules = ["build", "divide", "submit"]
